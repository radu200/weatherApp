
//weather api 
export  const REQUEST_WEATHER  = 'REQUEST_WEATHER'
export  const RECEIVE_WEATHER =  'RECEIVE_WEATHER'
export  const FAILURE_WEATHER =  'FAILURE_WEATHER'
export  const GET_DAY = 'GET_DAY' 